
# HFB — Calm Sky RF-520.4 (Patch)

**What this is:** a drop-in **assets/** patch that:
- Fixes theme toggle (Dark ↔ Calm) with persistence
- Sets final **Calm Sky** palette
- Guarantees **transparent logo** rendering (no white tile)

## How to deploy (1 step)
1) In your repo (`Hfb-landing`), open the `assets/` folder and **upload these 2 files**, overwriting if asked:
   - `assets/styles.css`
   - `assets/app.js`

No HTML edits required. The existing tag `<script src="assets/app.js" defer>` will pick up the new logic.

Tip: Hard refresh after deploy (⌘⇧R on Mac / Ctrl+F5 on Windows).
